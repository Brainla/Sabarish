import mongoose from "mongoose";

const card=mongoose.Schema({name:String,url:String});

export default mongoose.model('cards',card);
