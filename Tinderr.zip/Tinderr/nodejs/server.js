import express from "express";
import mongoose from "mongoose";
import cards from "./dbcards.js";
import cors from 'cors';
const app=express();
const port=process.env.PORT|| 8001
const connnetion="mongodb+srv://tinder-clone:25219996Vaj@@cluster0.xqyn2.mongodb.net/tinderdb?retryWrites=true&w=majority"

mongoose.connect(connnetion, {useNewUrlParser: true,useCreateIndex:true,useUnifiedTopology:true}
    );
app.get("/",(req,res)=>res.status(200).send("Hello Vaja"));

app.use(express.json());
app.use(cors());
app.post("/card",(req,res)=>{
    const newcard=res.body;

    cards.create(newcard,(err,data)=>{
        if(err){
        throw err;
        }
        else{
            res.status(201).send(data);
        }
    })
})

app.get("/card",(req,res)=>{
    cards.find((err,data)=>{
        if(err){
        throw err;
        }
        else{
            res.status(200).send(data);
            console.log(data)
        }
    })
})

app.listen(port,()=>console.log("Hello Welcome" ,`${port}`));
