import React from 'react'
import IconButton from '@material-ui/core/IconButton';
import PeopleIcon from '@material-ui/icons/People';
import ChatIcon from '@material-ui/icons/Chat';
import './header.css'
import WhatshotIcon from '@material-ui/icons/Whatshot';
function Header() {
    return ( 
    <div>
        <div className="flex-box">
        <IconButton>
        <PeopleIcon fontSize="large"/>
        </IconButton> 
        <IconButton className="icon"> 
        <WhatshotIcon fontSize="large"  />
        </IconButton> 
        <IconButton>
        <ChatIcon fontSize="large"/>
        </IconButton> 
        </div> 
         </div>
    )
}

export default Header;