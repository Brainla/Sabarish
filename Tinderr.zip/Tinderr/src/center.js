import Axios from 'axios';
import React, { useState, useEffect } from 'react';
import TinderCard from 'react-tinder-card';
import instance from './axios.js';
import './center.css'

function Center() {
    const onSwipe = (direction) => {
        console.log('You swiped: ' + direction)
      }
       
      const onCardLeftScreen = (myIdentifier) => {
        console.log(myIdentifier + ' left the screen')
      }
    const [People,setPeople]=useState([]);
    useEffect(()=>{
     async function fetchdata(){
         const req=await Axios.get('\card')
         setPeople(req.data);
        }
         fetchdata();
    },[])
    // {
    //     name:"Thejeshwar",
    //     url:"vaja.png",
    // },{
    //     name:"vajakathali",
    //     url:"../logo512.png",
    // },{
    //     name:"sai vignesh",
    //     url:"../logo192.png",
    // }
    return (
        <div className="container">
        <div className="swipe">
             {
            People.map((Person) => 
<TinderCard  className="tinder-card" key={Person.name} onSwipe={onSwipe} onCardLeftScreen={() => onCardLeftScreen('fooBar')} preventSwipe={['right', 'left']}>
               <div className="card" 
               style={{backgroundImage : `url(${Person.url})` }}
               >
                 <h3>{Person.name}</h3>
               </div>
</TinderCard>
            )}
            </div>
        
        </div>
    )}

export default Center;
