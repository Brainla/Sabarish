import React from 'react';
import ReplayIcon from '@material-ui/icons/Replay';
import ThumbDownIcon from '@material-ui/icons/ThumbDown';
import FlashOnIcon from '@material-ui/icons/FlashOn';
import FavoriteIcon from '@material-ui/icons/Favorite';
import GradeIcon from '@material-ui/icons/Grade';
import './footer.css';
import IconButton from '@material-ui/core/IconButton';
function Footer() {
    return (
        <div>
     <div className="flex-box-2">
        <IconButton  className="left">
        <ReplayIcon   fontSize="large"/>
        </IconButton> 
        <IconButton className="right"> 
        <ThumbDownIcon color="red" fontSize="large"/>
        </IconButton> 
        <IconButton className="north">
        <FlashOnIcon fontSize="large"/>
        </IconButton>
        <IconButton className="south">
        <FavoriteIcon fontSize="large"/>
        </IconButton> 
        <IconButton className="center">
        <GradeIcon fontSize="large"/>
        </IconButton>  
        </div> 
            
        </div>
    )
}

export default Footer
