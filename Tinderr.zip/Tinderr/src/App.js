import './App.css';
import Header from './header.js';
import Center from './center.js';
import Footer from './footer.js';
function App() {
    return ( 
        <div className = "app" >
        <Header />
        <Center />
        <Footer />
        </div>
    );
}

export default App;