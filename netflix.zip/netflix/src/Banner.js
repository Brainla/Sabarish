import React, { useEffect,useState } from 'react'
import axios from "./axios";
import requests from "./Request.js";
import './Banner.css';

 function Banner() {
    const [movie, setMovie] = useState([]);
    
    useEffect(() => {
        async function fetchData(){
        const request=await axios.get(requests.fetchNetfixOrginal);
        setMovie(request.data.results[
            Math.floor(Math.random()* request.data.results.length-1)       
             ]);
        console.log(request.data.results[
       Math.floor(Math.random()* request.data.results.length)       
        ])
        return requests
        }
        fetchData(); 
        }, []) 


    return (
        <header className="banner"
        style={
            {
                backgroundSize:"cover",backgroundImage:`url("https://image.tmdb.org/t/p/original/${movie.backdrop_path}")`,
                backgroundPosition:"center center"
            }
        }
        >
            
        <div className="banner_post">
        {/* title */}
        <h1 className="bannertitle">
                {movie?.name ||movie?.title || movie?.orginal_name}
        </h1>
        {/* play button */}
        <div className="button_banner">
            <button className="button">Play</button>
            <button className="button">My List</button>
        </div>
        {/* description */}
        <h1 className="banner-desc">
        {movie?.overview}
        </h1>

        </div>
        <div className="fade" />
            
        </header>
    )
}

export default Banner
