import './App.css';
import Row from './Row.js';
import requests from './Request.js';
import Banner from './Banner.js';
import Nav from "./nav.js";
function App() {
  return (
    <div className="app">
      <Nav />
    <Banner />
    <Row isLarge title="Netflix Orginal" fetchUrl={requests.fetchNetfixOrginal}/>
    <Row title="Treading" fetchUrl={requests.fetchTrending} />
    {/* <Row title="Comedy" fetchUrl={requests.fetchComedyMovie}/>  */}
    <Row title="Action Movie" fetchUrl={requests.fetchActionMovie}/>
    <Row title="Comedy Movie" fetchUrl={requests.fetchComedyMovie}/>
    <Row title="Horror Movie" fetchUrl={requests.fetchHorrorMovie}/>
    <Row title="Anime" fetchUrl={requests.fetchTopRated}/>
    <Row title="Documentry Movie" fetchUrl={requests.fetchDocMovie}/>

    </div>
  );
}

export default App;
