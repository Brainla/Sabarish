const Apikey="c7db7ba2195b1e83ea6b51153c0e1837";

const requests={
fetchTrending :`/trending/all/week?api_key=${Apikey}&language=en-US`,
fetchNetfixOrginal: `/discover/tv?api_key=${Apikey}&with_networks=213`,
fetchTopRated:`/tv/top_rated?api_key=${Apikey}&language=en-US&page=1`,
fetchActionMovie:`/discover/movie?api_key=${Apikey}&with_genres=28`,
fetchComedyMovie:`/discover/tv?api_key=${Apikey}&with_genres=35`,
fetchHorrorMovie:`/discover/tv?api_key=${Apikey}&with_genres=27`,
fetchDocMovie:`/discover/tv?api_key=${Apikey}&with_genres=99`,

} 

export default requests;