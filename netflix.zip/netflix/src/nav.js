import React from 'react'
import "./nav.css";
function Nav() {
    return (
        <div className="navbar">
            <img src="https://image.tmdb.org/t/p/original/wwemzKWzjKYJFfCeiB57q3r4Bcm.svg" 
            className="Nav-img" alt="Netflix-logo" />
        </div>
    )
}

export default Nav;
